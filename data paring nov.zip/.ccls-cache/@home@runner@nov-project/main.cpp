#include "uptime.hpp"
#include "meminfo.hpp"
#include "stat.hpp"

#include <unistd.h>

// function prototype 

// main Function //
int main ()
{ 
while (true)
  {		
  statClass sc;
  memInfoClass mi;
  upTimeClass uptc;
  uptc.clearScreen();
  std ::cout << "-------------------------------------------------"<< std::endl;
  std ::cout <<"Total cpu cores: "<<sc.getCount() <<'\n';
  std ::cout << "-------------------------------------------------"<< std::endl;
  std ::cout << "CPU " " busy " "   idle " "   system " " nice" <<'\n';
  sc.convertStatToPercentage();
		
  std ::cout << "-------------------------------------------------"<< std::endl;
  mi.converToMb();
  std ::cout << "-------------------------------------------------"<< std::endl;
  std::cout << "SYSTEM" << "  ";
  uptc.getUpTimeValue();
  std :: cout << "        ";
  uptc.getIdleTime();

  std ::cout << "-------------------------------------------------"<< std::endl;
  std::cout << "ENERGY" "  ";
  uptc.activeEnergy();
  std ::cout << "         ";
  uptc.idleEnergy();
  std ::cout << "-------------------------------------------------"<< std::endl;
  usleep(50000); // pause the program for half a second
  }
 }

// multi file program