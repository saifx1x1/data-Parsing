#include "meminfo.hpp"


// // parse, initialize & check if file is open
memInfoClass:: memInfoClass (){

	// defining the file object
  std ::string filename ="/proc/meminfo"; 
  std::ifstream input;
	
  input.open("/proc/meminfo");
if (!input.is_open()) std ::cerr <<"The proc meminfo file has not open";    

	// gets the the first five line of the meminfo file 
  for  (short x=0 ;x<5;x++)
    {
      getline(input,memi[x],':');
      input >> memval1[x];
      input >> kb[x];
      input.get();
    }
  input.close();
  }

// 

// converts from kB to MB 
void memInfoClass:: converToMb(){
  memi[0]="Total";
  memi[1]="Free";
  for (short x=0;x<5;x++){
  if(x==2) continue; // skips mem Available 
  if(x==0) std :: cout << "MEMORY     ";
  if(x!=0) std ::cout << "           ";
  std :: cout  <<memi[x]<<": "<<(memval1[x]/1024) <<' '<<"MB"<< '\n';
  }
}

