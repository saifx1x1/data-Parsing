#pragma once 

#include <unistd.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <iomanip>

class memInfoClass {
public:
 memInfoClass ();

//Converstion Functions
void converToMb ();


private:
// store parsed data
 int memval1[5];
 std ::string memi[5];
 std ::string kb[5];

};