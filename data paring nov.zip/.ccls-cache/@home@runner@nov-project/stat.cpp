#include "stat.hpp"


// constructor // parse , check & intialises variables  
// single arrray stores the values of a single collumn
statClass:: statClass (){
  std ::string fileName = "/proc/stat";
  std ::ifstream input;

  input.open(fileName);
  if (!input.is_open()) std :: cerr << "The /proc/stat file is not open" <<'\n';

  auto count = std::thread::hardware_concurrency(); // stores the number of cores
  for(int t =0;t<count+1;t++) 
  {    
  getline(input,statLine[t],' ');
    
  input >>userTime[t];
  input >>niceTime[t];
  input >>systemTime[t];
  input >>idleTime[t];

  input >>cpuValues5[t];
  input >>cpuValues6[t];
  input >>cpuValues7[t];
  input >>cpuValues8[t];
  input >>cpuValues9[t];
  input >>cpuValues10[t];
  input.get();
    } 
 input.close(); // close file 
}

// converts parse data to percentages // prints out to the console 
// stat total// total values for each row 
void statClass:: convertStatToPercentage(){
  for (short x=1; x<count+1;x++){
   if (int x=1){ 
		for (short s =1;s<count+1;s++){
     statTotal[s] = userTime[s] + idleTime[s] + systemTime[s]+ niceTime[s];
    }
	 }
    std::cout << std::fixed << std::setprecision(1) <<statLine[x] <<" "
              << ((userTime[x]/statTotal[x])*100)    <<"%    "  
              << ((idleTime[x]/statTotal[x])*100)    <<"%    " 
              << ((systemTime[x]/statTotal[x])*100)  <<"%    "   
              << ((niceTime[x]/statTotal[x])*100)    <<"%    " <<'\n';
  } 
}

// return count function 
short statClass::getCount(){
  return count;
}
