#pragma once 

#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <thread>


class statClass {

public :
statClass (); 

// Converts values to percentages & dissplays the value 
void convertStatToPercentage();

// get count function
short getCount();

private:
// store parse data // up to a 18 core system (look into vectors)
std ::string statLine[15];
  short count;
  float userTime[18];
  float niceTime[18];
  float systemTime[18];
  float idleTime[18];

  int cpuValues5[18];
  int cpuValues6[18];
  int cpuValues7[18];
  int cpuValues8[18];
  int cpuValues9[18];
  int cpuValues10[18];  

// function variales // convertStatToPercentage() 
int statTotal[18];
};
