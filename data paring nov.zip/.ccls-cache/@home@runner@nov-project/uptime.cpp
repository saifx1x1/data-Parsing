#include "uptime.hpp"

// // parse, initialize & check if file is open
upTimeClass ::upTimeClass ()
{
  std::ifstream upTimeFile("/proc/uptime");
  if (!upTimeFile.is_open()) std::cerr << "the uptime file has failed to open";
  
  while (getline(upTimeFile,time)){
    std::stringstream uptimestream(time);
    uptimestream >> val1;
    uptimestream >> val2;
    }
   upTimeFile.close(); // closes the file 
}

// CALCULATION FUNCTIONS 

//converts uptime seconds to hours seconds and minutes
void upTimeClass:: getUpTimeValue ()
{
  activeHours = val1/3600; 
  decimalHour= val1/3600; 
  minSecs = decimalHour -activeHours; 
  minSecs2 = minSecs *3600; 
  seconds = fmod(minSecs2,60); 
  second1 =seconds; 
  minutes = (minSecs2-seconds)/60; 
  
std :: cout << "UP for " << activeHours << " Hours " << minutes 
            << " minutes " << second1 <<" seconds " <<std ::endl;
}

// converts idle seconds to(hours ,minutes & seconds)
void upTimeClass:: getIdleTime (){
  
  val2 /=(getCount()-1); 
  Hours = val2/3600; 
  decimalHour1 = val2/3600; 
  minSecs3 = decimalHour1 -Hours;  
  minSecs4 = minSecs3 *3600; 
  seconds1 = fmod(minSecs4,60);  
  second2 =seconds1;  
  minutes2 = (minSecs4-seconds1)/60; 
  
std :: cout << "IDLE for " << Hours << " Hours " << minutes2 
            << " minutes " << second2 <<" seconds " <<std ::endl;
} 

// ENERGY FUNCTIONS 

// calulating the engergy used in active state
void upTimeClass::activeEnergy(){
  float activeEnergy1=val1 * 40;
  activeEnergy1/=1000000;
  
  std :: cout << "In active state " <<std::fixed << std::setprecision(2)<<activeEnergy1 
              << " Mjoules" <<'\n';
}


// calulating the engergy used in active state
void upTimeClass::idleEnergy(){
  float idleEnergy1 = val2*20;
  idleEnergy1/=1000000;

  std :: cout << "In idle state " <<std::fixed <<std::setprecision(2)<<idleEnergy1 
              << " Mjoules" << '\n';
}

// clean screen function 
void upTimeClass:: clearScreen(){
    std::cout << "\x1B[2J\x1B[H";
}
