#pragma once

#include "stat.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <cmath>
#include <iomanip>

class upTimeClass : public  statClass
{
public:
 upTimeClass (); // parse, initialize & check if file is open

// clear screen function
void clearScreen();

// Energy calculation functions
void activeEnergy();
void idleEnergy();

//uptime &idle  Seconds to (hours, minutes & seconds)
void getUpTimeValue ();
void getIdleTime ();

 private:
// store parsed data 
   std ::string time;
   float val1;
   float val2;

// function variables 
// getUpTimeValue () //variables 
  int activeHours;
  float decimalHour;
  float minSecs;
  float minSecs2;
  float seconds;
  short minutes;
  short second1;

//  getIdleTime () // variables
  int Hours;
  float decimalHour1;
  float minSecs3;
  float minSecs4;
  float seconds1;
  short minutes2;
  short second2;
};


